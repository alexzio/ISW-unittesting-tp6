package com.company;
import java.util.Date;
import java.util.Scanner;

public class catalogo {

        public String nombre;
        public String fechacreacion;
        public String fechafinvigencia;
        public int nrocatalogo;



 //constructor
public catalogo (String n, String fc, String ffv, int nro) {
        nombre = n;
        fechacreacion = fc;
        fechafinvigencia = ffv;
        nrocatalogo = nro; }


        //Metodo de modificar catalogo nombre
        public static void modificarcatalogonombre(catalogo obj){
                Scanner sc = new Scanner(System.in);
                String nombresuli = sc.nextLine();

                if(obj.fechafinvigencia!=null){
                        System.out.println("No se puede modificar a un catalogo ya dado de baja, el mismo tiene fecha de baja: "+ obj.fechafinvigencia);}
                else

                System.out.println("El catalogo ha sido modificado con el nombre '"+nombresuli+"' exitosamente!");

        }

//metodo dar baja catalogo
        public static void bajacatalogo(catalogo obj){

                if(obj.fechafinvigencia!=null){
                        System.out.println("No se puede dar de baja a un catalogo ya dado de baja, el mismo tiene fecha de baja: "+ obj.fechafinvigencia);}
               else
                System.out.println("El catalogo ha sido dado de baja exitosamente!");

        }
}
