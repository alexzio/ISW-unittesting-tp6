package com.company;

import java.util.Scanner;

import static com.company.catalogo.*;

public class Main {




    public static void main(String[] args) {
        catalogo a = new catalogo("notebook","12/10/2021","14/10/2021",001);
        catalogo b = new catalogo("electrodomesticos","12/10/2021","13/10/2021",002);
        catalogo c = new catalogo("verano","10/10/2021",null,003);

        //1-Intento modificar el nombre un catalogo dado ya de baja
        System.out.println("1) escriba el nombre del catalogo: '"+ a.nombre+"' por el cual quiera cambiarlo");

modificarcatalogonombre(a);
//2-Intento dar de baja un catalogo dado ya de baja
        System.out.println("2)");
        bajacatalogo(a);
//3-intento modificar el nombre un catalogo que no esta dado de baja
        System.out.println("3) escriba el nombre del catalogo: '"+ c.nombre+"' por el cual quiera cambiarlo");
modificarcatalogonombre(c);

        //4-Intento dar de baja un catalogo que no esta dado de baja
        System.out.println("4)");
        bajacatalogo(c);
    }
}
