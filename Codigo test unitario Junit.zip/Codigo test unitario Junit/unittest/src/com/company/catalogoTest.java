package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter
        .api.Assertions.*;

class catalogoTest {

    @Test
    void modificarcatalogo_dadobaja() {
        catalogo a = new catalogo("notebook","12/10/2021","14/10/2021",001);

        assertEquals(0, a.modificarcatalogo(a));
        //test completa, espero que me de 0 para indicarme que el catalogo no puede ser dado de baja
    }

    @Test
    void modificarcatalogo2() {

        catalogo b = new catalogo("frigos","12/10/2021",null,001);

        assertEquals(1, b.modificarcatalogo(b));
        //test completa, espero que me de un 1 dejandome asi modificar los param del catalogo
    }

    @Test
    void bajacatalogo_activo() {

        catalogo b = new catalogo("frigos","12/10/2021",null,001);

        assertEquals(0, b.bajacatalogo(b));

        //test falla, esperaba a que no me deje darle de baja al catalogo erroneamente, y me permite darlo de baja.
    }

    @Test
    void bajacatalogo_dadobaja() {
        catalogo a = new catalogo("notebook","12/10/2021","14/10/2021",001);

        assertEquals(0, a.bajacatalogo(a));

    }

}