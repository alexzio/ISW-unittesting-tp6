package com.company;
import java.util.Date;

public class catalogo {

        public String nombre;
        public String fechacreacion;
        public String fechafinvigencia;
        public int nrocatalogo;



 //constructor
public catalogo (String n, String fc, String ffv, int nro) {
        nombre = n;
        fechacreacion = fc;
        fechafinvigencia = ffv;
        nrocatalogo = nro; }


        //Metodo de modificar catalogo
        public int modificarcatalogo(catalogo obj){
               int d = 1;

                if(obj.fechafinvigencia!=null) {
                        d = 0;
                }
                else {


                }

                return d;
        }

//metodo dar baja catalogo
        public int bajacatalogo(catalogo obj){
                int x = 1;

                if(obj.fechafinvigencia!=null) {
                        x = 0;
                }
                else {


                }

                return x;
        }


        }

